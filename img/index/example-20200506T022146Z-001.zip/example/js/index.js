window.addEventListener("DOMContentLoaded",function(){
    //start
    //All system control
    navControl();
    visualControl();
// nav control
    function navControl(){
    $('.menu').on('mouseover',function(){
        $(this).find('div').stop().slideDown();
    })
    $('.menu').on('mouseleave',function(){
        $(this).find('div').stop().slideUp();
    })
    }
// visual control
    function visualControl(){
        var slider = $('.slideImg');
        var img = $('.slideImg').find('img');
        console.log(img.length)
        for(var i = 0; i < img.length; i++){
            img.eq(i).css({
                left:(i*100)+"%"
            })
        }
    }
    //end
})